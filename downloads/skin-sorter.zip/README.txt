this app can be used to sort and rename existing skinpacks!

first select all the skins which need to be sorted, and then press rename

the program will go through all the selected items, renaming them in the format "skin[n].png" and "skin[n]cape.png"

under advanced options, you can choose between copy mode and in-place mode:

copy mode creates a new skinpack which you can save wherever!

in-place mode overwrites the existing skins