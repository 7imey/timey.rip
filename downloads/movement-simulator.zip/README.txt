this app simulates movement in games to prevent afk kicks

the game has to be the active program for this to work though :/

the inactivity delay defines how long the program waits before simulating movement (assuming no keys are pressed)