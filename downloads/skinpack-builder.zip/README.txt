uploaded skins can have a cape, and also a hat or cigarette

the skin texture file MUST be named "skin[number].png" - i.e, skin1.png

the cape texture MUST be named "skin[number]cape.png" - i.e, skin1cape.png

there shouldn't be any gaps in the skins sequence; for example, you couldn't upload "skin1.png", "skin1cape.png", "skin3.png", and "skin3cape.png" - this would miss out skin 2

if the skin has a hat or a cigarette, you can select the relevant option from the dropdown box!
